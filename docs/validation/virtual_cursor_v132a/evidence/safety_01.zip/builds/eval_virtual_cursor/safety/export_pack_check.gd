extends SceneTree
func _initialize()->void:run.call_deferred()
func run()->void:
	var excluded={}
	for path in ["res://features/evaluator_virtual_cursor/scripts/replay_input_provider.gd","res://features/evaluator_virtual_cursor/scripts/virtual_cursor_driver.gd","res://features/evaluator_virtual_cursor/scripts/virtual_cursor_runner.gd","res://features/evaluator_qualification/scripts/qualification_driver.gd","res://features/auto_tuning_lab/scripts/optimization_trial_driver.gd"]:excluded[path]=not ResourceLoader.exists(path)
	var app=load("res://features/grip_up/scenes/grip_up_lab.tscn").instantiate();root.add_child(app);current_scene=app
	for frame in 5:await physics_frame
	var value={"release_template":not OS.is_debug_build(),"provider_disabled":app.replay_input_provider==null,"camera_virtual":app.camera.virtual_physics_follow,"profile":app.input_profile,"excluded":excluded}
	var file=FileAccess.open("C:/Users/Wynter/grip_up/builds/eval_virtual_cursor/safety/export_pack_check.json",FileAccess.WRITE);file.store_string(JSON.stringify(value));file.close()
	quit(0 if excluded.values().all(func(x):return x) and value.provider_disabled and not value.camera_virtual and value.profile==2 else 1)

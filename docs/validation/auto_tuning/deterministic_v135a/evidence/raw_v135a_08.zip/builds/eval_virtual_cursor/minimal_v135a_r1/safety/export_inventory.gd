extends SceneTree
var paths:Array[String]=[]
func walk(path:String)->void:
 for name in DirAccess.get_files_at(path):paths.append(path.path_join(name))
 for name in DirAccess.get_directories_at(path):walk(path.path_join(name))
func _initialize()->void:
 walk("res://");paths.sort()
 var forbidden=paths.filter(func(path:String):return path.begins_with("res://tools/") or path.begins_with("res://docs/") or path.begins_with("res://features/auto_tuning_lab/") or path.begins_with("res://features/evaluator_virtual_cursor/") or path.ends_with(".py") or "optuna" in path.to_lower())
 var output={"files":paths,"forbidden":forbidden,"pass":forbidden.is_empty(),"gameplay_bodies_created":0,"scope":"pack inventory only; no app instantiated"}
 var file=FileAccess.open("C:/Users/Wynter/grip_up/builds/eval_virtual_cursor/minimal_v135a_r1/safety/export_inventory.json",FileAccess.WRITE);file.store_string(JSON.stringify(output));file.close()
 quit(0 if forbidden.is_empty() else 1)
